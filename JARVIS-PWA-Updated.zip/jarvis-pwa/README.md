# J.A.R.V.I.S. — Android-ready AI assistant

A responsive Next.js PWA based on the supplied blue/black JARVIS HUD reference.

## Included
- Futuristic dashboard with responsive mobile layout
- Chat through a protected server route using Groq's OpenAI-compatible Chat Completions API
- ElevenLabs speech generation through a protected server route
- Browser speech recognition where supported; Android Chrome support depends on browser/device permissions
- Browser speech synthesis fallback
- Conversation history in local browser storage
- Stop speaking, mute, voice mode, volume, settings and clear-chat controls
- PWA manifest and service worker
- Battery/network/storage status where the browser exposes those APIs\n- Server-side configuration status endpoint (checks presence of Groq/ElevenLabs environment variables without exposing secrets)

## Security
Never put provider credentials in `NEXT_PUBLIC_*` variables or client code. Use `.env.local` locally and Vercel Environment Variables when deployed. The credentials previously pasted into chat should be rotated before production use.

## Configure
1. Copy `.env.example` to `.env.local`.
2. Set `GROQ_API_KEY` to a newly generated Groq key.
3. Set `ELEVENLABS_API_KEY` and `ELEVENLABS_VOICE_ID`.
4. Install and run:
   ```bash
   npm install
   npm run dev
   ```
5. Open `http://localhost:3000`.

## Deploy
Push this folder to a Git repository and import it into Vercel. Add the three environment variables in Project Settings → Environment Variables, then redeploy. Do not commit `.env.local`.

## API integration status and limitations
- Groq integration is implemented against `https://api.groq.com/openai/v1/chat/completions`.
- ElevenLabs integration is implemented against `https://api.elevenlabs.io/v1/text-to-speech/{voice_id}`.
- The third `sk_...` credential was not safely identifiable from its prefix alone. QROP documentation/base URL and auth format were not supplied, so no invented QROP endpoint is called. The app currently uses Groq for intelligence.
- Wake-word detection ("Hey JARVIS") is not implemented as an always-on background listener. It is not reliably supported by standard Android Chrome web APIs; tap-to-talk is provided.
- The browser cannot reliably read exact RAM, storage capacity, device model, or mobile carrier details. Status panel only shows values actually exposed by browser APIs and otherwise displays "Unavailable".
- This is source code, not a deployed live URL. Deployment requires a connected hosting account and environment variables.

## Android install
After HTTPS deployment, open the site in Chrome → menu ⋮ → Install app / Add to Home screen. Microphone access requires HTTPS (or localhost during development).
