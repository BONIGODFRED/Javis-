import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
export async function POST(req: NextRequest) {
  try {
    const key = process.env.ELEVENLABS_API_KEY;
    const voice = process.env.ELEVENLABS_VOICE_ID;
    if (!key || !voice) return NextResponse.json({ error: "ElevenLabs credentials are not configured." }, { status: 503 });
    const body = await req.json();
    if (typeof body.text !== "string" || !body.text.trim() || body.text.length > 5000) return NextResponse.json({ error: "Invalid speech text." }, { status: 400 });
    const upstream = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}`, {
      method: "POST",
      headers: { "xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg" },
      body: JSON.stringify({ text: body.text, model_id: "eleven_multilingual_v2", voice_settings: { stability: 0.48, similarity_boost: 0.78, style: 0.18, use_speaker_boost: true } }),
      signal: AbortSignal.timeout(45000)
    });
    if (!upstream.ok) {
      const detail = await upstream.text();
      return NextResponse.json({ error: `ElevenLabs returned ${upstream.status}: ${detail.slice(0,300)}` }, { status: upstream.status });
    }
    return new NextResponse(await upstream.arrayBuffer(), { headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" } });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Voice generation failed." }, { status: 500 });
  }
}