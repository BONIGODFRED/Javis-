import { NextResponse } from "next/server";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export async function GET() {
  const groq = Boolean(process.env.GROQ_API_KEY);
  const eleven = Boolean(process.env.ELEVENLABS_API_KEY && process.env.ELEVENLABS_VOICE_ID);
  return NextResponse.json({ groq, eleven, ready: groq }, { headers: { "Cache-Control": "no-store" } });
}
