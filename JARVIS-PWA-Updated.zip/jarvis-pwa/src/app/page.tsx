 "use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, Battery, BatteryCharging, Bot, BrainCircuit, CircleHelp, Command, Gauge, Globe2, Grid2X2, Home, Info, Menu, MessageSquare, Mic, MicOff, Monitor, Send, Settings, ShieldCheck, Signal, Sparkles, Volume2, VolumeX, Wifi, X, Youtube, Search, Play, Square, Trash2 } from "lucide-react";

type Msg={role:"user"|"assistant";content:string};
type Sys={battery:string;network:string;storage:string;device:string};
const starter:Msg={role:"assistant",content:"Good day, Sir. All systems are standing by. How may I assist you?"};
const nav=[["Home",Home],["Chat",MessageSquare],["Voice Control",Mic],["Quick Tools",Grid2X2],["Settings",Settings],["About",Info]] as const;

export default function HomePage(){
 const [messages,setMessages]=useState<Msg[]>([starter]);
 const [input,setInput]=useState(""); const [busy,setBusy]=useState(false);
 const [voiceMode,setVoiceMode]=useState(true); const [muted,setMuted]=useState(false);
 const [volume,setVolume]=useState(0.85); const [listening,setListening]=useState(false);
 const [speaking,setSpeaking]=useState(false); const [section,setSection]=useState("Home");
 const [settings,setSettings]=useState(false); const [status,setStatus]=useState<Sys>({battery:"Checking…",network:"Checking…",storage:"Checking…",device:"Browser device"});
 const [time,setTime]=useState("--:--"); const [date,setDate]=useState("");
 const [error,setError]=useState(""); const [mobileNav,setMobileNav]=useState(false); const [apiStatus,setApiStatus]=useState("Checking…");
 const recognition=useRef<any>(null); const audioRef=useRef<HTMLAudioElement|null>(null);
 const chatEnd=useRef<HTMLDivElement|null>(null);
 useEffect(()=>{const tick=()=>{const d=new Date();setTime(d.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}));setDate(d.toLocaleDateString([], {weekday:"short",month:"short",day:"numeric",year:"numeric"}));};tick();const id=setInterval(tick,1000);return()=>clearInterval(id)},[]);
 useEffect(()=>{if(typeof navigator!=="undefined"){setStatus(s=>({...s,network:navigator.onLine?"Connected":"Offline",device:/Android/i.test(navigator.userAgent)?"Android device":"Web device"}));const update=()=>setStatus(s=>({...s,network:navigator.onLine?"Connected":"Offline"}));window.addEventListener("online",update);window.addEventListener("offline",update);(navigator as any).getBattery?.().then((b:any)=>{const upd=()=>setStatus(s=>({...s,battery:`${Math.round(b.level*100)}%${b.charging?" · Charging":""}`}));upd();b.addEventListener("levelchange",upd);b.addEventListener("chargingchange",upd)}).catch(()=>setStatus(s=>({...s,battery:"Unavailable"})));(navigator as any).storage?.estimate?.().then((e:any)=>setStatus(s=>({...s,storage:e.quota?`${(e.usage/1e9).toFixed(2)} / ${(e.quota/1e9).toFixed(1)} GB`:"Unavailable"}))).catch(()=>{});return()=>{window.removeEventListener("online",update);window.removeEventListener("offline",update)}}},[]);
 useEffect(()=>{chatEnd.current?.scrollIntoView({behavior:"smooth"})},[messages,busy]);
 useEffect(()=>{if("serviceWorker" in navigator)navigator.serviceWorker.register("/sw.js").catch(()=>{})},[]);
 const speak=async(text:string)=>{if(muted||!voiceMode)return;setSpeaking(true);try{const r=await fetch("/api/voice",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text})});if(!r.ok)throw new Error("Voice service unavailable");const blob=await r.blob();const url=URL.createObjectURL(blob);if(audioRef.current){audioRef.current.pause();audioRef.current.src=url;audioRef.current.volume=volume;audioRef.current.onended=()=>{setSpeaking(false);URL.revokeObjectURL(url)};await audioRef.current.play()}}catch{if("speechSynthesis" in window){window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.volume=volume;u.onend=()=>setSpeaking(false);window.speechSynthesis.speak(u)}else setSpeaking(false)}};
 const send=async(text=input)=>{const q=text.trim();if(!q||busy)return;setInput("");setError("");const next=[...messages,{role:"user" as const,content:q}];setMessages(next);setBusy(true);try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:next.slice(-20)})});const data=await r.json();if(!r.ok)throw new Error(data.error||"Assistant request failed");const answer=data.reply||"I couldn't produce a response.";setMessages(m=>[...m,{role:"assistant",content:answer}]);await speak(answer)}catch(e:any){setError(e.message||"Connection error");setMessages(m=>[...m,{role:"assistant",content:"I'm unable to reach my intelligence service right now. Please check the backend configuration and try again."}])}finally{setBusy(false)}};
 const stop=()=>{audioRef.current?.pause();window.speechSynthesis?.cancel();setSpeaking(false)};
 const listen=()=>{const SR=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition;if(!SR){setError("Speech recognition is not available in this browser. Try the text command box.");return}try{const rec=new SR();rec.lang="en-US";rec.interimResults=false;rec.maxAlternatives=1;rec.onstart=()=>setListening(true);rec.onend=()=>setListening(false);rec.onerror=()=>{setListening(false);setError("Microphone unavailable. Check Chrome site permissions.")};rec.onresult=(e:any)=>{const t=e.results?.[0]?.[0]?.transcript||"";setInput(t);send(t)};recognition.current=rec;rec.start()}catch{setListening(false);setError("Could not start microphone. Allow microphone access in Chrome.")}};
 const clear=()=>{stop();setMessages([starter]);localStorage.removeItem("jarvis-chat");setError("")};
 useEffect(()=>{try{const saved=localStorage.getItem("jarvis-chat");if(saved)setMessages(JSON.parse(saved))}catch{}},[]);
 useEffect(()=>{try{localStorage.setItem("jarvis-chat",JSON.stringify(messages))}catch{}},[messages]);
 const shortcuts=[{name:"YouTube",icon:Youtube,url:"https://m.youtube.com"},{name:"Google",icon:Search,url:"https://google.com"},{name:"Play Store",icon:Play,url:"https://play.google.com/store"},{name:"More tools",icon:Grid2X2,url:"https://www.google.com"}];
 return <main className="app-shell">
  <header className="topbar hud">
   <button className="mobile-menu icon-btn" onClick={()=>setMobileNav(!mobileNav)}><Menu/></button>
   <div className="brand-mark"><span className="brand-a">A</span><div><div className="brand-name">JARVIS</div><div className="brand-sub">A I&nbsp; A S S I S T A N T</div></div></div>
   <div className="tagline">Always here. Always smarter.</div>
   <div className="clock"><strong>{time}</strong><span>{date}</span></div>
   <div className="top-indicators"><BatteryCharging/><span>{status.battery}</span><Signal/><span>ONLINE</span></div>
  </header>
  <div className="layout">
   <aside className={`sidebar ${mobileNav?"open":""}`}>{nav.map(([name,Icon])=><button key={name} className={`nav-item ${section===name?"active":""}`} onClick={()=>{setSection(name);setMobileNav(false);if(name==="Settings")setSettings(true)}}><Icon/><span>{name}</span></button>)}</aside>
   <section className="center-column">
    <div className="greeting hud"><span className="online-dot"/>Hello, Sir. <span className="wave">✦</span><br/><small>{section==="Home"?"Your assistant is ready. What shall we work on?":`${section} module selected.`}</small></div>
    <div className={`reactor ${busy||listening||speaking?"active":""}`} aria-label="JARVIS animated visualizer">
      <div className="reactor-ring ring-one"/><div className="reactor-ring ring-two"/><div className="reactor-ring ring-three"/><div className="reactor-ticks"/>
      <div className="reactor-core"><div className="core-triangle">▽</div><b>JARVIS</b><small>A I&nbsp; A S S I S T A N T</small></div>
    </div>
    <div className="earth"><Globe2/><span>GLOBAL NETWORK</span></div>
    <div className="voice-zone">
      <div className={`waveform ${speaking||listening?"moving":""}`}>{Array.from({length:27},(_,i)=><i key={i} style={{height:`${12+Math.abs(Math.sin(i*1.7))*48}px`}}/>)}</div>
      <button className={`mic-button ${listening?"listening":""}`} onClick={listening?()=>recognition.current?.stop():listen()} aria-label="Tap to speak"><Mic size={36}/></button>
      <div className="voice-label">{listening?"Listening…":speaking?"Speaking…":"Tap to speak"}</div>
      <button className="stop-btn" onClick={stop}><Square size={14}/> Stop</button>
    </div>
    <div className="chat-panel hud">
      <div className="chat-heading"><span><MessageSquare size={17}/> Conversation</span><button onClick={clear} title="Clear conversation"><Trash2 size={16}/></button></div>
      <div className="messages">{messages.slice(-12).map((m,i)=><div key={i} className={`message ${m.role}`}><b>{m.role==="assistant"?"JARVIS":"YOU"}</b><p>{m.content}</p></div>)}{busy&&<div className="thinking"><span/><span/><span/> JARVIS is thinking…</div>}<div ref={chatEnd}/></div>
      {error&&<div className="error-text">{error}</div>}
      <form className="command-bar" onSubmit={e=>{e.preventDefault();send()}}><MessageSquare/><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Type a command…" aria-label="Type a command"/><button disabled={busy||!input.trim()} aria-label="Send command"><Send/></button></form>
    </div>
   </section>
   <aside className="right-column">
    <section className="hud info-card"><h3><Activity/> SYSTEM STATUS</h3><div className="status-row"><Battery/><span>Battery</span><b>{status.battery}</b></div><div className="status-row"><Wifi/><span>Network</span><b className={status.network==="Connected"?"good":""}>{status.network}</b></div><div className="status-row"><Gauge/><span>Storage estimate</span><b>{status.storage}</b></div><div className="status-row"><Monitor/><span>Device</span><b>{status.device}</b></div><div className="status-row"><ShieldCheck/><span>API status</span><b className={apiStatus==="Groq configured"?"good":"warn"}>{apiStatus}</b></div></section>
    <section className="hud info-card"><h3><Sparkles/> QUICK ACTIONS</h3><div className="quick-grid">{shortcuts.map(s=><a key={s.name} href={s.url} target="_blank" rel="noreferrer"><s.icon/><span>{s.name}</span></a>)}</div></section>
    <section className="hud info-card tips"><h3><BrainCircuit/> JARVIS TIPS</h3><p>Try saying:</p><button onClick={()=>send("Explain how artificial intelligence works in simple terms.")}>“Explain AI to me”</button><button onClick={()=>send("Help me plan my day.")}>“Help me plan my day”</button><button onClick={()=>send("Give me a quick technology briefing.")}>“Give me a tech briefing”</button></section>
    <section className="hud info-card controls"><h3><Volume2/> VOICE SETTINGS</h3><div className="toggle-row"><span>Speak responses</span><button className={`toggle ${voiceMode?"on":""}`} onClick={()=>setVoiceMode(!voiceMode)}>{voiceMode?"ON":"OFF"}</button></div><div className="toggle-row"><span>Mute</span><button className={`toggle ${muted?"on":""}`} onClick={()=>{setMuted(!muted);if(!muted)stop()}}>{muted?"ON":"OFF"}</button></div><label>Volume <input type="range" min="0" max="1" step=".05" value={volume} onChange={e=>setVolume(+e.target.value)}/></label><button className="settings-link" onClick={()=>setSettings(true)}><Settings size={15}/> Open settings</button></section>
   </aside>
  </div>
  {settings&&<div className="modal-backdrop" onClick={()=>setSettings(false)}><div className="settings-modal hud" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setSettings(false)}><X/></button><h2><Settings/> JARVIS SETTINGS</h2><p>Voice output and device controls.</p><label className="toggle-row">Automatic voice responses <input type="checkbox" checked={voiceMode} onChange={e=>setVoiceMode(e.target.checked)}/></label><label className="toggle-row">Mute voice <input type="checkbox" checked={muted} onChange={e=>setMuted(e.target.checked)}/></label><label>Speech volume <input type="range" min="0" max="1" step=".05" value={volume} onChange={e=>setVolume(+e.target.value)}/></label><button className="primary-btn" onClick={()=>{clear();setSettings(false)}}>Clear conversation history</button><p className="fine-print">Microphone and speech recognition availability depend on Android Chrome, permissions and network support.</p></div></div>}
  <audio ref={audioRef} hidden/>
  <footer>J.A.R.V.I.S. <span>PERSONAL AI SYSTEM</span><span className="footer-right">SECURE SESSION · {status.network.toUpperCase()}</span></footer>
 </main>
}